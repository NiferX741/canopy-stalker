package com.niferx.canopystalker.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.niferx.canopystalker.CanopyStalkerMod;
import com.niferx.canopystalker.entity.CanopyStalkerEntity;
import com.niferx.canopystalker.entity.ai.CanopyStalkerState;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Yeux blancs seulement. Le corps n'a pas de veines lumineuses : il se fond
 * dans le sous-bois par sa texture.
 */
public class CanopyStalkerEyesLayer extends RenderLayer<CanopyStalkerEntity, CanopyStalkerModel> {
    private static final ResourceLocation GLOW = CanopyStalkerMod.id("textures/entity/canopy_stalker_eyes.png");

    public CanopyStalkerEyesLayer(RenderLayerParent<CanopyStalkerEntity, CanopyStalkerModel> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, CanopyStalkerEntity entity, float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        float tension = entity.getGazeProgress();
        float pulse = 0.5F + 0.5F * Mth.sin(ageInTicks * (0.2F + tension * 0.9F));
        float eyeAlpha = switch (entity.getStalkerState()) {
            case CAMOUFLAGE -> 0.22F + 0.08F * pulse;
            case STALKING -> 0.62F + 0.16F * pulse;
            case GAZE_AGGRO -> 0.8F + 0.2F * tension;
            case CHARGE_ATTACK -> 1.0F;
            case RETREAT_HIDE -> 0.35F;
        };

        VertexConsumer buffer = buffers.getBuffer(RenderType.eyes(GLOW));
        this.getParentModel().renderEyes(pose, buffer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, eyeAlpha);
    }
}

package com.niferx.canopystalker.entity.ai;

import com.niferx.canopystalker.entity.CanopyStalkerEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Cherche un bloc d'air où se tenir, appuyé sur un tronc ou des feuilles, avec
 * du feuillage autour. On ne pose pas l'entité dans un bloc solide : la physique
 * vanilla reste valide, et {@code WallClimberNavigation} gère les troncs.
 */
public final class CanopyPerchFinder {
    private CanopyPerchFinder() {
    }

    @Nullable
    public static BlockPos find(CanopyStalkerEntity stalker, int radius, @Nullable Vec3 awayFrom, BlockPos origin) {
        Level level = stalker.level();
        RandomSource random = stalker.getRandom();
        BlockPos best = null;
        double bestScore = Double.NEGATIVE_INFINITY;
        for (int attempt = 0; attempt < 28; attempt++) {
            BlockPos feet = origin.offset(
                    random.nextInt(radius * 2 + 1) - radius,
                    random.nextInt(radius + 6) - 3,
                    random.nextInt(radius * 2 + 1) - radius);
            if (!isStand(level, feet)) {
                continue;
            }
            double score = score(level, feet, origin, awayFrom);
            if (score > bestScore) {
                bestScore = score;
                best = feet.immutable();
            }
        }
        return best;
    }

    /**
     * Un poste d'observation loin du joueur, de préférence derrière son regard
     * et masqué par un bloc opaque. {@code null} si rien de tenable n'existe.
     */
    @Nullable
    public static BlockPos findHide(CanopyStalkerEntity stalker, Player player, double minDistance, double maxDistance) {
        Level level = stalker.level();
        RandomSource random = stalker.getRandom();
        Vec3 look = player.getLookAngle();
        double baseYaw = Math.atan2(look.z, look.x);
        int originY = player.blockPosition().getY();
        BlockPos best = null;
        double bestScore = Double.NEGATIVE_INFINITY;
        for (int attempt = 0; attempt < 40; attempt++) {
            double angle = baseYaw + Math.PI + (random.nextDouble() - 0.5D) * 2.4D;
            double distance = minDistance + random.nextDouble() * Math.max(1.0D, maxDistance - minDistance);
            int x = Mth.floor(player.getX() + Math.cos(angle) * distance);
            int z = Mth.floor(player.getZ() + Math.sin(angle) * distance);
            BlockPos feet = standNear(level, x, originY, z);
            if (feet == null) {
                continue;
            }
            double dx = feet.getX() + 0.5D - player.getX();
            double dz = feet.getZ() + 0.5D - player.getZ();
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            if (horizontal < minDistance - 2.0D) {
                continue;
            }
            Vec3 eye = new Vec3(feet.getX() + 0.5D, feet.getY() + stalker.getEyeHeight(), feet.getZ() + 0.5D);
            boolean blocked = blocksSight(level, player, eye);
            Vec3 flatLook = new Vec3(look.x, 0.0D, look.z);
            double dot = 1.0D;
            double flat = Math.sqrt(dx * dx + dz * dz);
            if (flatLook.lengthSqr() > 1.0E-4 && flat > 1.0E-4) {
                flatLook = flatLook.normalize();
                dot = flatLook.x * (dx / flat) + flatLook.z * (dz / flat);
            }
            if (!blocked && dot > 0.35D) {
                continue;
            }
            double score = (1.0D - dot) * 5.0D + (blocked ? 8.0D : 0.0D);
            score -= Math.sqrt(feet.distSqr(stalker.blockPosition())) * 0.06D;
            if (score > bestScore) {
                bestScore = score;
                best = feet.immutable();
            }
        }
        return best;
    }

    @Nullable
    private static BlockPos standNear(Level level, int x, int originY, int z) {
        for (int dy = 8; dy >= -8; dy--) {
            BlockPos feet = new BlockPos(x, originY + dy, z);
            if (isStand(level, feet)) {
                return feet;
            }
        }
        return null;
    }

    private static boolean blocksSight(Level level, Player player, Vec3 point) {
        BlockHitResult hit = level.clip(new ClipContext(
                player.getEyePosition(), point, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        return hit.getType() != HitResult.Type.MISS && hit.getLocation().distanceToSqr(point) > 1.5D;
    }

    public static boolean isStand(Level level, BlockPos feet) {
        BlockPos below = feet.below();
        BlockState floor = level.getBlockState(below);
        for (int dy = 0; dy <= 5; dy++) {
            if (!isPassable(level.getBlockState(feet.above(dy)))) {
                return false;
            }
        }
        boolean supported = floor.isFaceSturdy(level, below, Direction.UP)
                || floor.is(BlockTags.LOGS)
                || floor.is(BlockTags.LEAVES);
        return supported && hasCanopy(level, feet);
    }

    private static boolean isPassable(BlockState state) {
        return state.isAir() || state.is(BlockTags.LEAVES);
    }

    private static boolean hasCanopy(Level level, BlockPos feet) {
        for (int dy = 0; dy <= 4; dy++) {
            for (int dx = -2; dx <= 2; dx += 2) {
                for (int dz = -2; dz <= 2; dz += 2) {
                    BlockState state = level.getBlockState(feet.offset(dx, dy, dz));
                    if (state.is(BlockTags.LEAVES) || state.is(BlockTags.LOGS)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static double score(Level level, BlockPos feet, BlockPos origin, @Nullable Vec3 awayFrom) {
        double score = (feet.getY() - origin.getY()) * 0.45D;
        if (level.getBlockState(feet.above(2)).is(BlockTags.LEAVES)) {
            score += 2.0D;
        }
        if (level.getBlockState(feet.below()).is(BlockTags.LOGS)) {
            score += 1.5D;
        }
        if (awayFrom != null) {
            double dx = feet.getX() + 0.5D - awayFrom.x;
            double dz = feet.getZ() + 0.5D - awayFrom.z;
            score += Math.sqrt(dx * dx + dz * dz) * 0.4D;
        } else {
            score -= Math.sqrt(feet.distSqr(origin)) * 0.04D;
        }
        return score;
    }
}

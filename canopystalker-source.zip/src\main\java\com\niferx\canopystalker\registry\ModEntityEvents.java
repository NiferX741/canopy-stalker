package com.niferx.canopystalker.registry;

import com.niferx.canopystalker.CanopyStalkerMod;
import com.niferx.canopystalker.entity.CanopyStalkerEntity;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CanopyStalkerMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntityEvents {
    private ModEntityEvents() {
    }

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.CANOPY_STALKER.get(), CanopyStalkerEntity.createAttributes().build());
    }

    @SubscribeEvent
    public static void spawns(SpawnPlacementRegisterEvent event) {
        event.register(
                ModEntities.CANOPY_STALKER.get(),
                SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                CanopyStalkerEntity::checkCanopySpawnRules,
                SpawnPlacementRegisterEvent.Operation.OR);
    }
}

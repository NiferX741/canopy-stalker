package com.niferx.canopystalker.registry;

import com.niferx.canopystalker.CanopyStalkerMod;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Branchements audio. Les événements sont joués par l'entité et la machine à états.
 * Les fichiers réels se déclarent dans {@code assets/canopystalker/sounds.json}.
 * Le JSON actuel pointe vers des sons vanilla, à remplacer par tes .ogg.
 */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, CanopyStalkerMod.MOD_ID);

    public static final RegistryObject<SoundEvent> STALK = register("stalk");
    public static final RegistryObject<SoundEvent> GAZE_TENSION = register("gaze_tension");
    public static final RegistryObject<SoundEvent> CHARGE = register("charge");
    public static final RegistryObject<SoundEvent> SCREAM = register("scream");
    public static final RegistryObject<SoundEvent> ATTACK_IMPACT = register("attack_impact");
    public static final RegistryObject<SoundEvent> RUSTLE = register("rustle");
    public static final RegistryObject<SoundEvent> HURT = register("hurt");
    public static final RegistryObject<SoundEvent> DEATH = register("death");

    private ModSounds() {
    }

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(CanopyStalkerMod.id(name)));
    }
}

package com.niferx.canopystalker.entity;

import com.niferx.canopystalker.registry.ModParticles;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/**
 * Point d'entrée visuel côté serveur. Les particules vanilla partent tout de suite.
 * {@code eye_glint} passe par le type custom : le provider client est dans
 * {@code CanopyStalkerClient}. Pour un autre effet, ajouter un envoi ici.
 */
public final class CanopyStalkerEffects {
    private CanopyStalkerEffects() {
    }

    public static void chargeBurst(CanopyStalkerEntity stalker) {
        if (!(stalker.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 pos = stalker.position();
        server.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DARK_OAK_LEAVES.defaultBlockState()),
                pos.x, pos.y + 1.0D, pos.z, 8, 0.4D, 0.6D, 0.4D, 0.04D);
        server.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR,
                pos.x, pos.y + 1.2D, pos.z, 5, 0.3D, 0.45D, 0.3D, 0.01D);
        server.sendParticles(ParticleTypes.SQUID_INK,
                pos.x, pos.y + 0.8D, pos.z, 2, 0.15D, 0.25D, 0.15D, 0.01D);
    }

    public static void impact(Entity target) {
        if (!(target.level() instanceof ServerLevel server)) {
            return;
        }
        server.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DARK_OAK_LEAVES.defaultBlockState()),
                target.getX(), target.getY() + target.getBbHeight() * 0.5D, target.getZ(),
                12, 0.35D, 0.4D, 0.35D, 0.08D);
        server.sendParticles(ParticleTypes.WITCH,
                target.getX(), target.getY() + 1.0D, target.getZ(),
                8, 0.25D, 0.35D, 0.25D, 0.02D);
    }

    public static void eyeGlint(CanopyStalkerEntity stalker) {
        if (!(stalker.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 eye = stalker.getEyePosition();
        server.sendParticles(ModParticles.EYE_GLINT.get(), eye.x, eye.y, eye.z, 1, 0.12D, 0.06D, 0.12D, 0.0D);
    }
}

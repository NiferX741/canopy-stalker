package com.niferx.canopystalker.client;

import com.niferx.canopystalker.CanopyStalkerMod;
import com.niferx.canopystalker.client.particle.EyeGlintParticle;
import com.niferx.canopystalker.registry.ModEntities;
import com.niferx.canopystalker.registry.ModParticles;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CanopyStalkerMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class CanopyStalkerClient {
    private CanopyStalkerClient() {
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.CANOPY_STALKER.get(), CanopyStalkerRenderer::new);
    }

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(CanopyStalkerModel.LAYER, CanopyStalkerModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void particles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.EYE_GLINT.get(), EyeGlintParticle.Provider::new);
    }
}

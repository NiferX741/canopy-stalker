package com.niferx.canopystalker;

import com.niferx.canopystalker.config.CanopyStalkerConfig;
import com.niferx.canopystalker.registry.ModEffects;
import com.niferx.canopystalker.registry.ModEntities;
import com.niferx.canopystalker.registry.ModItems;
import com.niferx.canopystalker.registry.ModParticles;
import com.niferx.canopystalker.registry.ModSounds;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CanopyStalkerMod.MOD_ID)
public class CanopyStalkerMod {
    public static final String MOD_ID = "canopystalker";

    public CanopyStalkerMod(FMLJavaModLoadingContext context) {
        IEventBus bus = context.getModEventBus();
        ModEffects.EFFECTS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModParticles.PARTICLES.register(bus);
        bus.addListener(this::addCreative);
        context.registerConfig(ModConfig.Type.COMMON, CanopyStalkerConfig.SPEC);
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModItems.CANOPY_STALKER_SPAWN_EGG);
        }
    }
}

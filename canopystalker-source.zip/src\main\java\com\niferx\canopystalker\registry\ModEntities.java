package com.niferx.canopystalker.registry;

import com.niferx.canopystalker.CanopyStalkerMod;
import com.niferx.canopystalker.entity.CanopyStalkerEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CanopyStalkerMod.MOD_ID);

    public static final RegistryObject<EntityType<CanopyStalkerEntity>> CANOPY_STALKER = ENTITIES.register("canopy_stalker",
            () -> EntityType.Builder.of(CanopyStalkerEntity::new, MobCategory.MONSTER)
                    .sized(1.6F, 4.8F)
                    .clientTrackingRange(10)
                    .updateInterval(2)
                    .build(CanopyStalkerMod.MOD_ID + ":canopy_stalker"));

    private ModEntities() {
    }
}

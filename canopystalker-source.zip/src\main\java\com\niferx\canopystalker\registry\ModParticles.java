package com.niferx.canopystalker.registry;

import com.niferx.canopystalker.CanopyStalkerMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * La charge utilise aussi des particules vanilla (feuilles, spores, encre).
 * {@link #EYE_GLINT} est le type custom branché côté client dans {@code CanopyStalkerClient}.
 */
public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, CanopyStalkerMod.MOD_ID);

    public static final RegistryObject<SimpleParticleType> EYE_GLINT = PARTICLES.register("eye_glint",
            () -> new SimpleParticleType(false));

    private ModParticles() {
    }
}

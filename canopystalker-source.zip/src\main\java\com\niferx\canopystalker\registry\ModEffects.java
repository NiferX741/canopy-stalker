package com.niferx.canopystalker.registry;

import com.niferx.canopystalker.CanopyStalkerMod;
import com.niferx.canopystalker.effect.ObservedEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, CanopyStalkerMod.MOD_ID);

    public static final RegistryObject<MobEffect> OBSERVED = EFFECTS.register("observed", ObservedEffect::new);

    private ModEffects() {
    }
}

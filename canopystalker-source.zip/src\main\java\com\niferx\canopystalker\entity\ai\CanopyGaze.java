package com.niferx.canopystalker.entity.ai;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

/**
 * Vrai si le regard du joueur traverse la hitbox et que {@code hasLineOfSight} confirme
 * qu'aucun bloc opaque ne sépare les deux. Le produit scalaire seul rate les grands
 * modèles et déclenche trop tôt quand on regarde à côté.
 */
public final class CanopyGaze {
    private CanopyGaze() {
    }

    public static boolean isPlayerLookingAt(Player player, LivingEntity target, double maxDistance, double boxInflate) {
        if (!player.isAlive() || player.isSpectator()) {
            return false;
        }
        if (player.distanceToSqr(target) > maxDistance * maxDistance) {
            return false;
        }

        Vec3 from = player.getEyePosition();
        Vec3 look = player.getViewVector(1.0F);
        if (look.lengthSqr() < 1.0E-6) {
            return false;
        }
        look = look.normalize();

        Vec3 end = from.add(look.scale(maxDistance));
        BlockHitResult blockHit = player.level().clip(new ClipContext(
                from, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        double blockLimit = blockHit.getType() == HitResult.Type.MISS
                ? maxDistance
                : from.distanceTo(blockHit.getLocation()) + 0.05D;

        AABB box = target.getBoundingBox().inflate(boxInflate);
        Optional<Vec3> onBody = box.clip(from, from.add(look.scale(Math.min(maxDistance, blockLimit))));
        if (onBody.isEmpty()) {
            return false;
        }
        return player.hasLineOfSight(target);
    }
}

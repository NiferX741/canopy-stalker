package com.niferx.canopystalker.entity.ai;

/**
 * Noms stables à utiliser dans un contrôleur GeckoLib ou un {@code .animation.json} Blockbench.
 * Le modèle vanilla lit directement {@link CanopyStalkerState} ; ces constantes évitent
 * d'éparpiller des chaînes le jour où le renderer est remplacé.
 *
 * <p>Pour brancher GeckoLib 4 sans réécrire l'IA : faire implémenter {@code GeoEntity}
 * par {@code CanopyStalkerEntity}, puis choisir l'animation avec {@code getStalkerState()}
 * et {@code getGazeProgress()}. Dépendance commentée dans {@code build.gradle}.
 */
public final class CanopyStalkerAnimations {
    public static final String CAMOUFLAGE = "camouflage";
    public static final String STALK = "stalk";
    public static final String GAZE = "gaze";
    public static final String CHARGE = "charge";
    public static final String RETREAT = "retreat";

    private CanopyStalkerAnimations() {
    }

    public static String clipFor(CanopyStalkerState state) {
        return switch (state) {
            case CAMOUFLAGE -> CAMOUFLAGE;
            case STALKING -> STALK;
            case GAZE_AGGRO -> GAZE;
            case CHARGE_ATTACK -> CHARGE;
            case RETREAT_HIDE -> RETREAT;
        };
    }
}

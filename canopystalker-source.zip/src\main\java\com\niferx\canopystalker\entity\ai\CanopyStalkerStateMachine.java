package com.niferx.canopystalker.entity.ai;

import com.niferx.canopystalker.config.CanopyStalkerConfig;
import com.niferx.canopystalker.entity.CanopyStalkerEffects;
import com.niferx.canopystalker.entity.CanopyStalkerEntity;
import com.niferx.canopystalker.registry.ModEffects;
import com.niferx.canopystalker.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Un seul propriétaire pour les transitions. Les goals vanilla ne font que
 * nager ({@code FloatGoal}) : le déplacement passe par la navigation, donc
 * camouflage, regard et charge ne se marchent pas dessus.
 */
public final class CanopyStalkerStateMachine {
    private final CanopyStalkerEntity stalker;
    private int tensionStep;
    private int lostSight;
    private int impactPause = -1;
    private int hideCooldown;
    public CanopyStalkerStateMachine(CanopyStalkerEntity stalker) {
        this.stalker = stalker;
    }

    public void tick() {
        this.stalker.incrementStateTicks();
        switch (this.stalker.getStalkerState()) {
            case CAMOUFLAGE -> this.tickCamouflage();
            case STALKING -> this.tickStalking();
            case GAZE_AGGRO -> this.tickGaze();
            case CHARGE_ATTACK -> this.tickCharge();
            case RETREAT_HIDE -> this.tickRetreat();
        }
    }

    /**
     * Un coup reçu sort le stalker du couvert et lance la charge.
     * Remplacer ce corps si un coup doit plutôt forcer le repli.
     */
    public void onAttacked(Player player) {
        if (!this.stalker.isAlive() || !this.stalker.isHuntTarget(player)) {
            return;
        }
        this.stalker.setTarget(player);
        if (this.stalker.getStalkerState() != CanopyStalkerState.CHARGE_ATTACK) {
            this.transition(CanopyStalkerState.CHARGE_ATTACK);
        }
    }

    private void tickCamouflage() {
        Player player = this.stalker.findNearestPlayer(this.noticeRange());
        if (player != null) {
            this.stalker.setTarget(player);
            this.transition(CanopyStalkerState.STALKING);
            return;
        }
        this.stalker.getNavigation().stop();
        this.holdStill();
        this.stalker.setSettled(true);
    }

    private void tickStalking() {
        Player player = this.lockedPlayer();
        if (player == null) {
            this.stalker.getNavigation().stop();
            this.holdStill();
            this.transition(CanopyStalkerState.CAMOUFLAGE);
            return;
        }
        this.stalker.getLookControl().setLookAt(player, 50.0F, 40.0F);
        if (CanopyGaze.isPlayerLookingAt(player, this.stalker, this.watchRange(), CanopyStalkerConfig.gazeBoxInflate)) {
            this.transition(CanopyStalkerState.GAZE_AGGRO);
            return;
        }
        this.stalker.setGazeTicks(this.stalker.getGazeTicks() - CanopyStalkerConfig.gazeDecayPerTick);

        if (this.isHiddenFrom(player)) {
            this.stalker.getNavigation().stop();
            this.holdStill();
            this.stalker.setSettled(true);
            return;
        }
        this.creepToHide(player);
    }

    private void tickGaze() {
        Player player = this.lockedPlayer();
        if (player == null) {
            this.transition(CanopyStalkerState.RETREAT_HIDE);
            return;
        }
        this.stalker.getLookControl().setLookAt(player, 40.0F, 40.0F);
        this.holdStill();

        boolean looking = CanopyGaze.isPlayerLookingAt(
                player, this.stalker, this.watchRange(), CanopyStalkerConfig.gazeBoxInflate);
        if (looking) {
            this.stalker.setGazeTicks(this.stalker.getGazeTicks() + 1);
            this.playTensionCue();
            if (this.stalker.tickCount % Math.max(1, CanopyStalkerConfig.eyeGlintInterval) == 0) {
                CanopyStalkerEffects.eyeGlint(this.stalker);
            }
            this.applyObserved(player);
            if (this.stalker.getGazeTicks() >= CanopyStalkerConfig.gazeTicksRequired) {
                this.transition(CanopyStalkerState.CHARGE_ATTACK);
            }
        } else {
            this.stalker.setGazeTicks(this.stalker.getGazeTicks() - CanopyStalkerConfig.gazeDecayPerTick);
            if (this.stalker.getGazeTicks() <= 0) {
                player.removeEffect(ModEffects.OBSERVED.get());
                this.transition(CanopyStalkerState.STALKING);
            } else {
                this.applyObserved(player);
            }
        }
    }

    private void tickCharge() {
        if (this.impactPause >= 0) {
            this.stalker.getNavigation().stop();
            this.holdStill();
            if (--this.impactPause <= 0) {
                this.stalker.setStruckThisCharge(false);
                this.impactPause = -1;
            }
            return;
        }

        Player player = this.lockedPlayer();
        if (player == null) {
            this.transition(CanopyStalkerState.RETREAT_HIDE);
            return;
        }
        this.stalker.getLookControl().setLookAt(player, 70.0F, 70.0F);
        this.stalker.getNavigation().moveTo(player, CanopyStalkerConfig.chargeSpeed);
        if (this.stalker.tickCount % 3 == 0) {
            CanopyStalkerEffects.chargeBurst(this.stalker);
        }
        if (!this.stalker.hasStruckThisCharge()
                && this.stalker.distanceToSqr(player) <= this.stalker.getMeleeAttackRangeSqr(player)
                && this.stalker.doHurtTarget(player)) {
            this.stalker.setStruckThisCharge(true);
            this.impactPause = Math.max(CanopyStalkerConfig.impactPauseTicks, 12);
        }
    }

    private void tickRetreat() {
        Player player = this.stalker.getTarget() instanceof Player current && this.stalker.isHuntTarget(current)
                ? current
                : null;
        if (player == null) {
            this.stalker.getNavigation().stop();
            this.transition(CanopyStalkerState.CAMOUFLAGE);
            return;
        }
        if (this.stalker.distanceTo(player) >= this.hideDistance() || this.stalker.getStateTicks() > 80) {
            this.transition(CanopyStalkerState.STALKING);
            return;
        }
        Vec3 away = this.stalker.position().subtract(player.position());
        away = new Vec3(away.x, 0.0D, away.z);
        if (away.lengthSqr() < 1.0E-4) {
            away = new Vec3(1.0D, 0.0D, 0.0D);
        }
        Vec3 dest = this.stalker.position().add(away.normalize().scale(8.0D));
        this.stalker.setSettled(false);
        this.stalker.getNavigation().moveTo(dest.x, dest.y, dest.z, CanopyStalkerConfig.retreatSpeed);
    }

    private void transition(CanopyStalkerState next) {
        if (this.stalker.getStalkerState() == next) {
            return;
        }
        this.stalker.setStalkerState(next);
        this.lostSight = 0;
        this.impactPause = -1;
        this.tensionStep = 0;
        if (next != CanopyStalkerState.GAZE_AGGRO) {
            this.clearObserved();
        }
        switch (next) {
            case CAMOUFLAGE -> {
                this.stalker.setTarget(null);
                this.stalker.setGazeTicks(0);
                this.stalker.setStruckThisCharge(false);
                this.stalker.getNavigation().stop();
                this.stalker.setSettled(false);
            }
            case STALKING -> {
                this.stalker.setSettled(false);
                this.stalker.setPerchPos(null);
                this.hideCooldown = 0;
            }
            case GAZE_AGGRO -> this.stalker.getNavigation().stop();
            case CHARGE_ATTACK -> {
                this.stalker.setSettled(false);
                this.stalker.setStruckThisCharge(false);
                this.stalker.setPerchPos(null);
                this.stalker.playSound(ModSounds.SCREAM.get(), 2.5F, 1.0F);
                CanopyStalkerEffects.chargeBurst(this.stalker);
            }
            case RETREAT_HIDE -> {
                this.stalker.setGazeTicks(0);
                this.stalker.setPerchPos(null);
                this.stalker.setSettled(false);
                this.stalker.playSound(ModSounds.RUSTLE.get(), 0.7F, 0.75F + this.stalker.getRandom().nextFloat() * 0.2F);
            }
        }
    }

    private void applyObserved(Player player) {
        int required = Math.max(1, CanopyStalkerConfig.gazeTicksRequired);
        int amplifier = Mth.clamp(this.stalker.getGazeTicks() * 4 / required, 0, 4);
        player.removeEffect(ModEffects.OBSERVED.get());
        player.addEffect(new MobEffectInstance(ModEffects.OBSERVED.get(), 40, amplifier, false, true, true), this.stalker);
    }

    private void clearObserved() {
        if (this.stalker.getTarget() instanceof Player player) {
            player.removeEffect(ModEffects.OBSERVED.get());
        }
    }

    private void playTensionCue() {
        int required = Math.max(1, CanopyStalkerConfig.gazeTicksRequired);
        int step = this.stalker.getGazeTicks() * 3 / required;
        if (step <= this.tensionStep) {
            return;
        }
        this.tensionStep = step;
        float pitch = 0.55F + step * 0.28F;
        this.stalker.playSound(ModSounds.GAZE_TENSION.get(), 0.35F + step * 0.12F, pitch);
    }

    @Nullable
    private Player lockedPlayer() {
        double lose = this.loseRange();
        if (this.stalker.getTarget() instanceof Player current
                && this.stalker.isHuntTarget(current)
                && this.stalker.distanceToSqr(current) <= lose * lose) {
            return current;
        }
        Player found = this.stalker.findNearestPlayer(this.noticeRange());
        this.stalker.setTarget(found);
        return found;
    }

    private double noticeRange() {
        return Math.max(CanopyStalkerConfig.noticeRange, 48.0D);
    }

    private double loseRange() {
        return Math.max(CanopyStalkerConfig.loseTargetRange, 72.0D);
    }

    /** Distance minimale à laquelle il accepte de s'arrêter pour observer. */
    private double hideDistance() {
        return Math.max(CanopyStalkerConfig.preferredStalkDistance, 30.0D);
    }

    private double watchRange() {
        return Math.max(CanopyStalkerConfig.gazeRange, this.hideDistance() + 14.0D);
    }

    /**
     * Assez loin, et soit masqué par un bloc, soit hors du regard du joueur.
     */
    private boolean isHiddenFrom(Player player) {
        double distance = this.stalker.distanceTo(player);
        double min = this.hideDistance();
        if (distance < min || distance > min + 18.0D) {
            return false;
        }
        if (!player.hasLineOfSight(this.stalker)) {
            return true;
        }
        Vec3 look = player.getLookAngle();
        Vec3 flatLook = new Vec3(look.x, 0.0D, look.z);
        double dx = this.stalker.getX() - player.getX();
        double dz = this.stalker.getZ() - player.getZ();
        double flat = dx * dx + dz * dz;
        if (flatLook.lengthSqr() < 1.0E-4 || flat < 1.0E-4) {
            return false;
        }
        flat = Math.sqrt(flat);
        flatLook = flatLook.normalize();
        double dot = flatLook.x * (dx / flat) + flatLook.z * (dz / flat);
        return dot < 0.1D;
    }

    private void creepToHide(Player player) {
        BlockPos perch = this.stalker.getPerchPos();
        if (perch != null && !this.perchStillUseful(player, perch)) {
            this.stalker.setPerchPos(null);
            perch = null;
        }
        if (perch == null) {
            if (this.hideCooldown > 0) {
                this.hideCooldown--;
            } else {
                perch = CanopyPerchFinder.findHide(this.stalker, player, this.hideDistance(), this.hideDistance() + 14.0D);
                this.hideCooldown = perch == null ? 12 : 8;
                this.stalker.setPerchPos(perch);
            }
        }
        if (perch == null) {
            this.slipBehind(player);
            return;
        }
        if (this.stalker.isCloseToPerch(3.0D)) {
            this.stalker.getNavigation().stop();
            this.holdStill();
            this.stalker.setPerchPos(null);
            return;
        }
        this.stalker.setSettled(false);
        this.stalker.getNavigation().moveTo(perch.getX() + 0.5D, perch.getY(), perch.getZ() + 0.5D, CanopyStalkerConfig.stalkSpeed);
        if (this.stalker.getNavigation().isDone() && this.stalker.getStateTicks() > 50) {
            this.stalker.setPerchPos(null);
        }
    }

    private boolean perchStillUseful(Player player, BlockPos perch) {
        double dx = perch.getX() + 0.5D - player.getX();
        double dz = perch.getZ() + 0.5D - player.getZ();
        if (dx * dx + dz * dz < (this.hideDistance() - 4.0D) * (this.hideDistance() - 4.0D)) {
            return false;
        }
        return CanopyPerchFinder.isStand(this.stalker.level(), perch);
    }

    private void slipBehind(Player player) {
        Vec3 look = player.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0D, look.z);
        if (flat.lengthSqr() < 1.0E-4) {
            flat = new Vec3(0.0D, 0.0D, 1.0D);
        }
        Vec3 dest = player.position().subtract(flat.normalize().scale(this.hideDistance()));
        this.stalker.setSettled(false);
        this.stalker.getNavigation().moveTo(dest.x, player.getY(), dest.z, CanopyStalkerConfig.stalkSpeed);
    }

    private void holdStill() {
        Vec3 motion = this.stalker.getDeltaMovement();
        this.stalker.setDeltaMovement(motion.x * 0.2D, motion.y, motion.z * 0.2D);
    }

}

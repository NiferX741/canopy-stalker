package com.niferx.canopystalker.entity.ai;

import com.niferx.canopystalker.entity.CanopyStalkerEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.pathfinder.Path;

import javax.annotation.Nullable;
import java.util.Set;

/**
 * En poursuite, le chemin est calculé avec la taille rampante, donc un passage
 * d'un ou deux blocs reste franchissable. Hors poursuite, la taille debout est gardée.
 */
public class CanopyPursuitNavigation extends WallClimberNavigation {
    public CanopyPursuitNavigation(CanopyStalkerEntity mob, Level level) {
        super(mob, level);
    }

    @Nullable
    @Override
    protected Path createPath(Set<BlockPos> targets, int regionOffset, boolean offsetUpward, int accuracy) {
        CanopyStalkerEntity stalker = (CanopyStalkerEntity) this.mob;
        if (stalker.getStalkerState() != CanopyStalkerState.CHARGE_ATTACK) {
            return super.createPath(targets, regionOffset, offsetUpward, accuracy);
        }
        stalker.setPathingCrawler(true);
        try {
            return super.createPath(targets, regionOffset, offsetUpward, accuracy);
        } finally {
            stalker.setPathingCrawler(false);
        }
    }
}

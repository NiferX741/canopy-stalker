package com.niferx.canopystalker.client;

import com.niferx.canopystalker.CanopyStalkerMod;
import com.niferx.canopystalker.entity.CanopyStalkerEntity;
import com.niferx.canopystalker.entity.ai.CanopyStalkerState;
import com.niferx.canopystalker.registry.ModEffects;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Tremblement de caméra tant que l'effet Observé est actif. L'amplitude suit
 * le temps de fixation : faible au début, violent juste avant la charge.
 */
@Mod.EventBusSubscriber(modid = CanopyStalkerMod.MOD_ID, value = Dist.CLIENT)
public final class ObservedCameraShake {
    private ObservedCameraShake() {
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        Minecraft minecraft = Minecraft.getInstance();
        Player player = minecraft.player;
        if (player == null || minecraft.level == null || minecraft.isPaused()) {
            return;
        }
        float stare = stareStrength(minecraft, player);
        if (stare <= 0.02F) {
            return;
        }
        float time = (player.tickCount + (float) event.getPartialTick()) * 0.5F;
        float amp = stare * stare;
        float roll = Mth.sin(time * 9.0F) * 2.6F * amp + Mth.sin(time * 23.0F) * 0.7F * amp;
        float pitch = Mth.cos(time * 11.0F) * 1.35F * amp;
        float yaw = Mth.sin(time * 7.0F) * 0.85F * amp;
        event.setRoll(event.getRoll() + roll);
        event.setPitch(event.getPitch() + pitch);
        event.setYaw(event.getYaw() + yaw);
    }

    private static float stareStrength(Minecraft minecraft, Player player) {
        float best = 0.0F;
        AABB area = player.getBoundingBox().inflate(40.0D);
        for (CanopyStalkerEntity stalker : minecraft.level.getEntitiesOfClass(CanopyStalkerEntity.class, area)) {
            if (stalker.getStalkerState() != CanopyStalkerState.GAZE_AGGRO) {
                continue;
            }
            best = Math.max(best, stalker.getGazeProgress());
        }
        if (best > 0.0F) {
            return best;
        }
        MobEffectInstance effect = player.getEffect(ModEffects.OBSERVED.get());
        if (effect == null) {
            return 0.0F;
        }
        return Mth.clamp((effect.getAmplifier() + 1) / 5.0F, 0.0F, 1.0F);
    }
}

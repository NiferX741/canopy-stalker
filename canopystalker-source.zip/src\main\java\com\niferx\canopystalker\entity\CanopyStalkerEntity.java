package com.niferx.canopystalker.entity;

import com.niferx.canopystalker.config.CanopyStalkerConfig;
import com.niferx.canopystalker.entity.ai.CanopyPursuitNavigation;
import com.niferx.canopystalker.entity.ai.CanopyStalkerState;
import com.niferx.canopystalker.entity.ai.CanopyStalkerStateMachine;
import com.niferx.canopystalker.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;

/**
 * Caméléon de la canopée. L'IA est dans {@link CanopyStalkerStateMachine}.
 * L'état et la tension du regard sont synchronisés pour le renderer et, plus tard, GeckoLib.
 *
 * <p>Signatures vérifiées sur Forge 1.20.1-47.4.29 : {@code defineSynchedData()}
 * sans argument (le {@code Builder} date de 1.20.2), accès au monde via
 * {@code level()}, marche haute via {@code setMaxUpStep}. {@code getEyeHeight}
 * est final ; la valeur vanilla est déjà 85 % de la hauteur.
 */
public class CanopyStalkerEntity extends Monster {
    private static final EntityDataAccessor<Byte> DATA_STATE =
            SynchedEntityData.defineId(CanopyStalkerEntity.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Byte> DATA_GAZE_PROGRESS =
            SynchedEntityData.defineId(CanopyStalkerEntity.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Byte> DATA_FLAGS =
            SynchedEntityData.defineId(CanopyStalkerEntity.class, EntityDataSerializers.BYTE);
    private static final byte FLAG_CLIMBING = 1;
    private static final EntityDimensions CROUCH_DIMENSIONS = EntityDimensions.scalable(1.15F, 1.45F);
    private static final EntityDimensions CRAWL_DIMENSIONS = EntityDimensions.scalable(0.9F, 0.7F);

    private boolean pathingCrawler;

    private final CanopyStalkerStateMachine brain = new CanopyStalkerStateMachine(this);
    private int gazeTicks;
    private int stateTicks;
    private boolean chargeHit;
    private boolean settled;
    @Nullable
    private BlockPos perchPos;

    public CanopyStalkerEntity(EntityType<CanopyStalkerEntity> type, Level level) {
        super(type, level);
        this.setMaxUpStep(1.25F);
        this.setPathfindingMalus(BlockPathTypes.LEAVES, 0.0F);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 32.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.26D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.ARMOR, 2.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.35D);
    }

    public static boolean checkCanopySpawnRules(EntityType<CanopyStalkerEntity> type, ServerLevelAccessor level, MobSpawnType reason, BlockPos pos, RandomSource random) {
        if (CanopyStalkerConfig.requireNightToSpawn && !level.getLevel().isNight()) {
            return false;
        }
        if (!Monster.checkMonsterSpawnRules(type, level, reason, pos, random)) {
            return false;
        }
        for (int dy = 2; dy <= 12; dy++) {
            if (level.getBlockState(pos.above(dy)).is(BlockTags.LEAVES)) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_STATE, CanopyStalkerState.CAMOUFLAGE.id());
        this.entityData.define(DATA_GAZE_PROGRESS, (byte) 0);
        this.entityData.define(DATA_FLAGS, (byte) 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        return new CanopyPursuitNavigation(this, level);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        if (this.pathingCrawler || pose == Pose.SWIMMING) {
            return CRAWL_DIMENSIONS;
        }
        if (pose == Pose.CROUCHING) {
            return CROUCH_DIMENSIONS;
        }
        return super.getDimensions(pose);
    }

    /**
     * Le chemin de poursuite est calculé avec la taille rampante, puis la hitbox
     * réelle est restaurée. Ne pas laisser ce drapeau actif en dehors du calcul.
     */
    public void setPathingCrawler(boolean pathingCrawler) {
        this.pathingCrawler = pathingCrawler;
        this.refreshDimensions();
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        this.refreshConfiguredAttributes();
        this.brain.tick();
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            boolean pursuing = this.getStalkerState() == CanopyStalkerState.CHARGE_ATTACK;
            this.setClimbing(pursuing && this.horizontalCollision);
            Pose pose = pursuing ? this.poseForPursuit() : Pose.STANDING;
            if (this.getPose() != pose) {
                this.setPose(pose);
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !this.level().isClientSide && source.getEntity() instanceof Player player) {
            this.brain.onAttacked(player);
        }
        return hurt;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity living) {
            this.playSound(ModSounds.CHARGE.get(), 2.5F, 1.0F);
            this.playSound(ModSounds.ATTACK_IMPACT.get(), 0.45F, 0.9F + this.random.nextFloat() * 0.15F);
            living.addEffect(new MobEffectInstance(this.resolveAttackEffect(), CanopyStalkerConfig.effectDuration, CanopyStalkerConfig.effectAmplifier), this);
            CanopyStalkerEffects.impact(target);
        }
        return hit;
    }

    @Override
    public double getMeleeAttackRangeSqr(LivingEntity target) {
        return super.getMeleeAttackRangeSqr(target) + CanopyStalkerConfig.attackReachBonus;
    }

    @Override
    public int getAmbientSoundInterval() {
        return this.getStalkerState() == CanopyStalkerState.STALKING ? 200 : 480;
    }

    @Override
    public void playAmbientSound() {
        if (this.getStalkerState() == CanopyStalkerState.STALKING) {
            this.playSound(ModSounds.STALK.get(), 2.5F, 1.0F);
            return;
        }
        super.playAmbientSound();
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return switch (this.getStalkerState()) {
            case STALKING -> ModSounds.STALK.get();
            case CAMOUFLAGE, RETREAT_HIDE -> ModSounds.RUSTLE.get();
            case GAZE_AGGRO, CHARGE_ATTACK -> null;
        };
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.DEATH.get();
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        if (this.getStalkerState() != CanopyStalkerState.CAMOUFLAGE) {
            super.playStepSound(pos, state);
        }
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        CanopyStalkerState state = this.getStalkerState();
        if (state == CanopyStalkerState.STALKING || state == CanopyStalkerState.GAZE_AGGRO || state == CanopyStalkerState.CHARGE_ATTACK) {
            return false;
        }
        return super.removeWhenFarAway(distanceToClosestPlayer);
    }

    @Override
    public boolean isPushable() {
        return this.getStalkerState() != CanopyStalkerState.CAMOUFLAGE && super.isPushable();
    }

    @Override
    public boolean onClimbable() {
        return this.isClimbing();
    }

    /** 1 bloc : rampe. 2 blocs : se baisse. Au-delà, il reste debout. */
    private Pose poseForPursuit() {
        int space = this.passageClearance();
        if (space <= 1) {
            return Pose.SWIMMING;
        }
        if (space == 2) {
            return Pose.CROUCHING;
        }
        return Pose.STANDING;
    }

    private int passageClearance() {
        BlockPos feet = this.blockPosition();
        int here = this.openColumn(feet);
        BlockPos ahead = feet.relative(this.getDirection());
        if (!this.isOpen(ahead)) {
            return here;
        }
        int forward = this.openColumn(ahead);
        BlockPos further = ahead.relative(this.getDirection());
        if (this.isOpen(further)) {
            forward = Math.min(forward, this.openColumn(further));
        }
        return Math.min(here, forward);
    }

    private int openColumn(BlockPos feet) {
        int open = 0;
        for (int dy = 0; dy < 6; dy++) {
            if (!this.isOpen(feet.above(dy))) {
                break;
            }
            open++;
        }
        return open;
    }

    private boolean isOpen(BlockPos pos) {
        BlockState state = this.level().getBlockState(pos);
        return state.isAir() || state.is(BlockTags.LEAVES) || state.getCollisionShape(this.level(), pos).isEmpty();
    }

    @Override
    public int getExperienceReward() {
        return 8 + this.random.nextInt(5);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("StalkerState", this.getStalkerState().name());
        tag.putInt("GazeTicks", this.gazeTicks);
        tag.putInt("StateTicks", this.stateTicks);
        tag.putBoolean("ChargeHit", this.chargeHit);
        if (this.perchPos != null) {
            tag.putInt("PerchX", this.perchPos.getX());
            tag.putInt("PerchY", this.perchPos.getY());
            tag.putInt("PerchZ", this.perchPos.getZ());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        CanopyStalkerState state = CanopyStalkerState.CAMOUFLAGE;
        if (tag.contains("StalkerState")) {
            try {
                state = CanopyStalkerState.valueOf(tag.getString("StalkerState"));
            } catch (IllegalArgumentException ignored) {
                state = CanopyStalkerState.CAMOUFLAGE;
            }
        }
        this.setStalkerState(state);
        this.stateTicks = tag.getInt("StateTicks");
        this.setGazeTicks(tag.getInt("GazeTicks"));
        this.chargeHit = tag.getBoolean("ChargeHit");
        if (tag.contains("PerchX")) {
            this.perchPos = new BlockPos(tag.getInt("PerchX"), tag.getInt("PerchY"), tag.getInt("PerchZ"));
        }
    }

    public CanopyStalkerState getStalkerState() {
        return CanopyStalkerState.byId(this.entityData.get(DATA_STATE));
    }

    public void setStalkerState(CanopyStalkerState state) {
        if (this.getStalkerState() != state) {
            this.entityData.set(DATA_STATE, state.id());
            this.stateTicks = 0;
        }
    }

    /** 0 quand personne ne fixe le stalker, 1 quand le compteur de charge est plein. */
    public float getGazeProgress() {
        return (this.entityData.get(DATA_GAZE_PROGRESS) & 255) / 100.0F;
    }

    public int getGazeTicks() {
        return this.gazeTicks;
    }

    public void setGazeTicks(int ticks) {
        this.gazeTicks = Math.max(0, ticks);
        int required = Math.max(1, CanopyStalkerConfig.gazeTicksRequired);
        int progress = Mth.clamp(this.gazeTicks * 100 / required, 0, 100);
        byte packed = (byte) progress;
        if (this.entityData.get(DATA_GAZE_PROGRESS) != packed) {
            this.entityData.set(DATA_GAZE_PROGRESS, packed);
        }
    }

    public int getStateTicks() {
        return this.stateTicks;
    }

    public void incrementStateTicks() {
        this.stateTicks++;
    }

    public void resetStateTicks() {
        this.stateTicks = 0;
    }

    public boolean hasStruckThisCharge() {
        return this.chargeHit;
    }

    public void setStruckThisCharge(boolean struck) {
        this.chargeHit = struck;
    }

    public boolean isSettled() {
        return this.settled;
    }

    public void setSettled(boolean settled) {
        this.settled = settled;
    }

    @Nullable
    public BlockPos getPerchPos() {
        return this.perchPos;
    }

    public void setPerchPos(@Nullable BlockPos perchPos) {
        this.perchPos = perchPos == null ? null : perchPos.immutable();
    }

    public boolean isCloseToPerch(double distance) {
        return this.perchPos != null && this.blockPosition().distSqr(this.perchPos) <= distance * distance;
    }

    public boolean isExposedToSun() {
        return this.isSunBurnTick();
    }

    public boolean isClimbing() {
        return (this.entityData.get(DATA_FLAGS) & FLAG_CLIMBING) != 0;
    }

    public void setClimbing(boolean climbing) {
        byte flags = this.entityData.get(DATA_FLAGS);
        byte updated = climbing ? (byte) (flags | FLAG_CLIMBING) : (byte) (flags & ~FLAG_CLIMBING);
        if (flags != updated) {
            this.entityData.set(DATA_FLAGS, updated);
        }
    }

    @Nullable
    public Player findNearestPlayer(double range) {
        return this.level().getNearestPlayer(this.getX(), this.getY(), this.getZ(), range, this::isHuntTarget);
    }

    public boolean isHuntTarget(Entity entity) {
        if (!(entity instanceof Player player)) {
            return false;
        }
        return player.isAlive()
                && !player.isSpectator()
                && !player.isInvisible();
    }

    private void refreshConfiguredAttributes() {
        if (this.tickCount % 40 != 0) {
            return;
        }
        this.setBase(Attributes.MOVEMENT_SPEED, CanopyStalkerConfig.movementSpeed);
        this.setBase(Attributes.ATTACK_DAMAGE, CanopyStalkerConfig.attackDamage);
        this.setBase(Attributes.ARMOR, CanopyStalkerConfig.armor);
        this.setBase(Attributes.FOLLOW_RANGE, CanopyStalkerConfig.followRange);
        this.setBase(Attributes.KNOCKBACK_RESISTANCE, CanopyStalkerConfig.knockbackResistance);
        AttributeInstance health = this.getAttribute(Attributes.MAX_HEALTH);
        if (health != null && health.getBaseValue() != CanopyStalkerConfig.maxHealth) {
            float ratio = this.getMaxHealth() <= 0.0F ? 1.0F : this.getHealth() / this.getMaxHealth();
            health.setBaseValue(CanopyStalkerConfig.maxHealth);
            this.setHealth(this.getMaxHealth() * Mth.clamp(ratio, 0.0F, 1.0F));
        }
    }

    private void setBase(net.minecraft.world.entity.ai.attributes.Attribute attribute, double value) {
        AttributeInstance instance = this.getAttribute(attribute);
        if (instance != null && instance.getBaseValue() != value) {
            instance.setBaseValue(value);
        }
    }

    private MobEffect resolveAttackEffect() {
        ResourceLocation id = ResourceLocation.tryParse(CanopyStalkerConfig.attackEffect);
        if (id == null) {
            return MobEffects.POISON;
        }
        MobEffect effect = ForgeRegistries.MOB_EFFECTS.getValue(id);
        return effect == null ? MobEffects.POISON : effect;
    }
}

package com.niferx.canopystalker.client;

import com.niferx.canopystalker.CanopyStalkerMod;
import com.niferx.canopystalker.entity.CanopyStalkerEntity;
import com.niferx.canopystalker.entity.ai.CanopyStalkerAnimations;
import com.niferx.canopystalker.entity.ai.CanopyStalkerState;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Pose;

/**
 * Renderer vanilla. Pour GeckoLib, remplacer cette classe par un {@code GeoEntityRenderer}
 * et choisir le clip avec {@link CanopyStalkerAnimations#clipFor(CanopyStalkerState)}.
 * L'entité expose déjà {@code getStalkerState()} et {@code getGazeProgress()}.
 */
public class CanopyStalkerRenderer extends MobRenderer<CanopyStalkerEntity, CanopyStalkerModel> {
    private static final ResourceLocation TEXTURE = CanopyStalkerMod.id("textures/entity/canopy_stalker.png");

    public CanopyStalkerRenderer(EntityRendererProvider.Context context) {
        super(context, new CanopyStalkerModel(context.bakeLayer(CanopyStalkerModel.LAYER)), 0.4F);
        this.addLayer(new CanopyStalkerEyesLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(CanopyStalkerEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(CanopyStalkerEntity entity, float yaw, float partialTick, com.mojang.blaze3d.vertex.PoseStack pose, net.minecraft.client.renderer.MultiBufferSource buffers, int light) {
        if (entity.getPose() == Pose.SWIMMING) {
            this.shadowRadius = 0.3F;
        } else if (entity.getPose() == Pose.CROUCHING) {
            this.shadowRadius = 0.5F;
        } else {
            this.shadowRadius = entity.getStalkerState() == CanopyStalkerState.CAMOUFLAGE ? 0.25F : 0.9F;
        }
        super.render(entity, yaw, partialTick, pose, buffers, light);
    }

    @Override
    protected boolean shouldShowName(CanopyStalkerEntity entity) {
        return super.shouldShowName(entity) && entity.getStalkerState() != CanopyStalkerState.CAMOUFLAGE;
    }

    @Override
    protected int getBlockLightLevel(CanopyStalkerEntity entity, BlockPos pos) {
        int light = super.getBlockLightLevel(entity, pos);
        if (entity.getStalkerState() == CanopyStalkerState.CHARGE_ATTACK) {
            return Math.max(light, 6);
        }
        return light;
    }
}

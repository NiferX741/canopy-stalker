package com.niferx.canopystalker.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.niferx.canopystalker.CanopyStalkerMod;
import com.niferx.canopystalker.entity.CanopyStalkerEntity;
import com.niferx.canopystalker.entity.ai.CanopyStalkerState;
import net.minecraft.client.model.EntityModel;
import net.minecraft.world.entity.Pose;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Silhouette calée sur le concept : jambes longues et écartées, torse étroit,
 * bras jusqu'au sol, couronne de vrilles, deux yeux carrés.
 * Y positif vers le bas, le pivot est posé sur les pieds (Y = 24).
 */
public class CanopyStalkerModel extends EntityModel<CanopyStalkerEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(CanopyStalkerMod.id("canopy_stalker"), "main");
    private static final int TENDRILS = 12;
    private static final float THIGH = 22.0F;
    private static final float SHIN_TO_SOLE = 18.8F;

    private final ModelPart pivot;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart armLeftUpper;
    private final ModelPart armLeftLower;
    private final ModelPart armRightUpper;
    private final ModelPart armRightLower;
    private final ModelPart legLeftUpper;
    private final ModelPart legLeftLower;
    private final ModelPart legRightUpper;
    private final ModelPart legRightLower;
    private final ModelPart[] tendrils;
    private final ModelPart[] glowParts;
    private final GlowPart[] eyes;

    public CanopyStalkerModel(ModelPart root) {
        this.pivot = root.getChild("pivot");
        this.torso = this.pivot.getChild("torso");
        this.head = this.torso.getChild("head");
        this.armLeftUpper = this.torso.getChild("arm_left_upper");
        this.armLeftLower = this.armLeftUpper.getChild("arm_left_lower");
        this.armRightUpper = this.torso.getChild("arm_right_upper");
        this.armRightLower = this.armRightUpper.getChild("arm_right_lower");
        this.legLeftUpper = this.pivot.getChild("leg_left_upper");
        this.legLeftLower = this.legLeftUpper.getChild("leg_left_lower");
        this.legRightUpper = this.pivot.getChild("leg_right_upper");
        this.legRightLower = this.legRightUpper.getChild("leg_right_lower");

        this.tendrils = new ModelPart[TENDRILS];
        for (int i = 0; i < TENDRILS; i++) {
            this.tendrils[i] = this.head.getChild("tendril_" + i);
        }

        ModelPart[] headChain = {this.pivot, this.torso, this.head};
        this.eyes = new GlowPart[] {
                glow(this.head, "eye_left", headChain),
                glow(this.head, "eye_right", headChain)
        };
        this.glowParts = new ModelPart[] {this.eyes[0].part, this.eyes[1].part};
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition pivot = root.addOrReplaceChild("pivot", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));

        PartDefinition legLeft = pivot.addOrReplaceChild("leg_left_upper",
                cube(0, 36, -3.0F, 0.0F, -3.0F, 6.0F, 22.0F, 6.0F),
                PartPose.offsetAndRotation(4.2F, -40.0F, 0.0F, 0.0F, 0.0F, -0.04F));
        PartDefinition legLeftLower = legLeft.addOrReplaceChild("leg_left_lower",
                cube(0, 66, -2.6F, 0.0F, -2.6F, 5.2F, 16.0F, 5.2F),
                PartPose.offset(0.0F, 22.0F, 0.0F));
        legLeftLower.addOrReplaceChild("foot_left",
                cube(52, 36, -3.2F, 0.0F, -5.2F, 6.4F, 2.8F, 8.2F),
                PartPose.offset(0.0F, 16.0F, 0.4F));

        PartDefinition legRight = pivot.addOrReplaceChild("leg_right_upper",
                cube(26, 36, -3.0F, 0.0F, -3.0F, 6.0F, 22.0F, 6.0F),
                PartPose.offsetAndRotation(-4.2F, -40.0F, 0.0F, 0.0F, 0.0F, 0.04F));
        PartDefinition legRightLower = legRight.addOrReplaceChild("leg_right_lower",
                cube(24, 66, -2.6F, 0.0F, -2.6F, 5.2F, 16.0F, 5.2F),
                PartPose.offset(0.0F, 22.0F, 0.0F));
        legRightLower.addOrReplaceChild("foot_right",
                cube(52, 50, -3.2F, 0.0F, -5.2F, 6.4F, 2.8F, 8.2F),
                PartPose.offset(0.0F, 16.0F, 0.4F));

        PartDefinition torso = pivot.addOrReplaceChild("torso",
                cube(0, 0, -5.0F, -26.0F, -3.5F, 10.0F, 26.0F, 7.0F),
                PartPose.offset(0.0F, -40.0F, 0.0F));
        torso.addOrReplaceChild("rib_0", cube(36, 0, -6.2F, -20.0F, -4.1F, 12.4F, 2.2F, 1.2F), PartPose.ZERO);
        torso.addOrReplaceChild("rib_1", cube(36, 6, -6.6F, -15.0F, -4.2F, 13.2F, 2.0F, 1.2F), PartPose.ZERO);
        torso.addOrReplaceChild("rib_2", cube(36, 12, -5.8F, -10.0F, -4.0F, 11.6F, 1.8F, 1.2F), PartPose.ZERO);

        PartDefinition head = torso.addOrReplaceChild("head",
                cube(68, 0, -4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, -26.0F, 0.0F));
        head.addOrReplaceChild("eye_left",
                cube(0, 0, 0.0F, 0.0F, 0.0F, 2.6F, 2.3F, 1.3F),
                PartPose.offset(-3.3F, -5.6F, -4.8F));
        head.addOrReplaceChild("eye_right",
                cube(0, 0, 0.0F, 0.0F, 0.0F, 2.6F, 2.3F, 1.3F),
                PartPose.offset(0.7F, -5.6F, -4.8F));
        addTendrils(head);

        PartDefinition armLeft = torso.addOrReplaceChild("arm_left_upper",
                cube(84, 18, -2.5F, 0.0F, -2.5F, 5.0F, 24.0F, 5.0F),
                PartPose.offsetAndRotation(6.4F, -23.0F, 0.0F, 0.2F, 0.0F, -0.38F));
        PartDefinition forearmLeft = armLeft.addOrReplaceChild("arm_left_lower",
                cube(84, 50, -2.2F, 0.0F, -2.2F, 4.4F, 22.0F, 4.4F),
                PartPose.offsetAndRotation(0.0F, 22.5F, 0.4F, -0.42F, 0.0F, -0.1F));
        addClaw(forearmLeft, "claw_left", 1.0F);

        PartDefinition armRight = torso.addOrReplaceChild("arm_right_upper",
                cube(106, 18, -2.5F, 0.0F, -2.5F, 5.0F, 24.0F, 5.0F),
                PartPose.offsetAndRotation(-6.4F, -23.0F, 0.0F, 0.2F, 0.0F, 0.38F));
        PartDefinition forearmRight = armRight.addOrReplaceChild("arm_right_lower",
                cube(106, 50, -2.2F, 0.0F, -2.2F, 4.4F, 22.0F, 4.4F),
                PartPose.offsetAndRotation(0.0F, 22.5F, 0.4F, -0.42F, 0.0F, 0.1F));
        addClaw(forearmRight, "claw_right", -1.0F);

        return LayerDefinition.create(mesh, 128, 128);
    }

    private static void addTendrils(PartDefinition head) {
        for (int i = 0; i < TENDRILS; i++) {
            float around = i * ((float) (Math.PI * 2.0D) / TENDRILS);
            boolean droop = i % 5 == 0;
            float length = droop ? 22.0F : 14.0F + (i % 4) * 3.2F;
            float pitch = droop ? 0.85F : -1.2F + (i % 3) * 0.32F;
            head.addOrReplaceChild("tendril_" + i,
                    cube(0, 96, -1.15F, -length, -1.15F, 2.3F, length, 2.3F),
                    PartPose.offsetAndRotation(
                            Mth.cos(around) * 3.4F,
                            droop ? -1.5F : -5.5F,
                            Mth.sin(around) * 3.4F,
                            pitch,
                            around,
                            Mth.cos(around) * (droop ? 0.4F : 0.9F)));
        }
    }

    private static void addClaw(PartDefinition forearm, String name, float side) {
        forearm.addOrReplaceChild(name + "_a",
                cube(48, 64, 0.0F, 0.0F, 0.0F, 1.3F, 6.0F, 1.3F),
                PartPose.offsetAndRotation(side * 0.4F, 20.5F, -1.6F, 0.5F, 0.0F, side * 0.35F));
        forearm.addOrReplaceChild(name + "_b",
                cube(56, 64, 0.0F, 0.0F, 0.0F, 1.2F, 5.2F, 1.2F),
                PartPose.offsetAndRotation(side * 1.3F, 20.2F, -0.4F, 0.35F, 0.0F, side * 0.55F));
    }

    private static CubeListBuilder cube(int u, int v, float x, float y, float z, float w, float h, float d) {
        return CubeListBuilder.create().texOffs(u, v).addBox(x, y, z, w, h, d);
    }

    @Override
    public void setupAnim(CanopyStalkerEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.pivot.getAllParts().forEach(ModelPart::resetPose);
        CanopyStalkerState state = entity.getStalkerState();
        float progress = entity.getGazeProgress();
        float breathe = Mth.sin(ageInTicks * 0.08F) * 0.025F;
        float stride = Mth.cos(limbSwing * 0.55F) * limbSwingAmount;

        this.torso.xRot = 0.12F + breathe;
        this.poseLegs(stride, 0.9F);
        this.poseArms(0.22F, -0.42F, -0.45F, Mth.sin(ageInTicks * 0.07F) * 0.03F);

        switch (state) {
            case CAMOUFLAGE -> this.writhe(ageInTicks, 0.08F, 0.045F);
            case STALKING -> {
                this.torso.xRot = 0.28F + breathe;
                this.torso.zRot = Mth.sin(ageInTicks * 0.05F) * 0.05F;
                this.look(netHeadYaw, headPitch, 1.0F);
                this.poseArms(0.3F, -0.5F, -0.4F, Mth.sin(ageInTicks * 0.14F) * 0.06F);
                if ((int) ageInTicks % 80 < 6) {
                    this.head.zRot += 0.22F;
                    this.armLeftUpper.xRot = -0.35F;
                }
                this.writhe(ageInTicks, 0.16F, 0.11F);
            }
            case GAZE_AGGRO -> {
                float tension = 0.35F + progress;
                this.torso.xRot = 0.18F + progress * 0.62F;
                float shake = Mth.sin(ageInTicks * (1.6F + progress * 7.5F)) * (0.015F + progress * 0.07F);
                this.torso.zRot = shake;
                this.look(netHeadYaw, headPitch, 0.65F);
                this.head.xRot -= progress * 0.25F;
                this.head.zRot += shake * 1.4F;
                this.poseArms(-0.15F - progress * 1.2F, -0.55F - progress * 0.4F, -0.55F - progress * 0.35F, 0.0F);
                this.armLeftLower.xRot = -0.2F - progress * 0.55F;
                this.armRightLower.xRot = -0.2F - progress * 0.55F;
                this.writhe(ageInTicks, 0.25F + progress * 1.35F, 0.08F + progress * 0.32F);
                if (tension > 1.2F) {
                    this.armLeftUpper.zRot -= 0.08F;
                }
            }
            case CHARGE_ATTACK -> {
                float flail = Mth.sin(ageInTicks * 1.35F);
                this.torso.xRot = 0.95F;
                this.head.xRot = -0.55F;
                this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD * 0.4F;
                this.armLeftUpper.xRot = -1.75F + flail * 0.28F;
                this.armRightUpper.xRot = -1.6F - flail * 0.28F;
                this.armLeftUpper.zRot = -0.15F;
                this.armRightUpper.zRot = 0.15F;
                this.armLeftLower.xRot = -0.15F;
                this.armRightLower.xRot = -0.1F;
                float lunge = Mth.cos(ageInTicks * 0.9F);
                this.poseLegs(lunge, 1.25F);
                this.writhe(ageInTicks, 1.15F, 0.42F);
            }
            case RETREAT_HIDE -> {
                this.torso.xRot = 0.7F + breathe;
                this.head.xRot = 0.45F;
                this.poseArms(0.55F, -0.7F, -0.25F, 0.0F);
                this.poseLegs(stride, 1.15F);
                this.writhe(ageInTicks, 0.22F, 0.07F);
                for (ModelPart tendril : this.tendrils) {
                    tendril.xRot += 0.45F;
                }
            }
        }

        if (entity.isClimbing()) {
            this.poseClimb(ageInTicks);
        } else if (entity.getPose() == Pose.SWIMMING) {
            this.poseCrawl(limbSwing, limbSwingAmount, ageInTicks);
        } else if (entity.getPose() == Pose.CROUCHING) {
            this.poseCrouch(limbSwing, limbSwingAmount);
            this.plantFeet();
        } else {
            this.plantFeet();
        }
    }

    /** Baisse le bassin pour que la semelle la plus basse reste au sol. */
    private void plantFeet() {
        float drop = Math.min(this.legLift(this.legLeftUpper, this.legLeftLower), this.legLift(this.legRightUpper, this.legRightLower));
        if (drop <= 0.0F) {
            return;
        }
        this.legLeftUpper.y += drop;
        this.legRightUpper.y += drop;
        this.torso.y += drop;
    }

    private float legLift(ModelPart upper, ModelPart lower) {
        float thigh = THIGH * Mth.cos(upper.xRot) * Mth.cos(upper.zRot);
        float shin = SHIN_TO_SOLE * Mth.cos(upper.xRot + lower.xRot);
        float vertical = Math.max(0.0F, thigh) + Math.max(0.0F, shin);
        return Math.max(0.0F, (THIGH + SHIN_TO_SOLE) - vertical);
    }

    private void poseCrouch(float limbSwing, float limbSwingAmount) {
        float crawl = Mth.cos(limbSwing * 0.7F) * limbSwingAmount;
        this.torso.xRot = 1.05F;
        this.head.xRot -= 0.7F;
        this.poseArms(-0.8F, -0.35F, -0.9F, crawl * 0.35F);
        this.legLeftUpper.xRot = 1.05F + crawl * 0.25F;
        this.legRightUpper.xRot = 1.05F - crawl * 0.25F;
        this.legLeftLower.xRot = 1.35F;
        this.legRightLower.xRot = 1.35F;
        for (ModelPart tendril : this.tendrils) {
            tendril.xRot += 0.8F;
        }
    }

    private void poseCrawl(float limbSwing, float limbSwingAmount, float age) {
        float crawl = Mth.cos(limbSwing * 0.9F) * Math.max(0.45F, limbSwingAmount);
        if (Math.abs(crawl) < 0.2F) {
            crawl = Mth.cos(age * 0.35F) * 0.35F;
        }
        this.pivot.xRot = 1.4F;
        this.pivot.y += 8.0F;
        this.torso.xRot = 0.15F;
        this.head.xRot = -1.15F;
        this.poseArms(-1.35F, -0.2F, -0.45F, crawl * 0.7F);
        this.legLeftUpper.xRot = 0.35F - crawl * 0.55F;
        this.legRightUpper.xRot = 0.35F + crawl * 0.55F;
        this.legLeftLower.xRot = 0.8F;
        this.legRightLower.xRot = 0.8F;
        for (ModelPart tendril : this.tendrils) {
            tendril.xRot += 1.1F;
        }
    }

    private void poseClimb(float age) {
        float reach = Mth.sin(age * 0.45F);
        this.torso.xRot = 0.28F;
        this.torso.zRot = reach * 0.06F;
        this.head.xRot = -0.35F;
        this.armLeftUpper.xRot = -2.6F + reach * 0.85F;
        this.armRightUpper.xRot = -2.6F - reach * 0.85F;
        this.armLeftUpper.zRot = -0.15F;
        this.armRightUpper.zRot = 0.15F;
        this.armLeftLower.xRot = -0.35F - Math.max(0.0F, reach) * 0.4F;
        this.armRightLower.xRot = -0.35F - Math.max(0.0F, -reach) * 0.4F;
        this.legLeftUpper.xRot = 0.55F - reach * 0.75F;
        this.legRightUpper.xRot = 0.55F + reach * 0.75F;
        this.legLeftLower.xRot = 0.95F;
        this.legRightLower.xRot = 0.95F;
        this.writhe(age, 0.5F, 0.12F);
    }

    private void look(float netHeadYaw, float headPitch, float weight) {
        this.head.yRot += netHeadYaw * Mth.DEG_TO_RAD * weight;
        this.head.xRot += headPitch * Mth.DEG_TO_RAD * weight;
    }

    private void poseLegs(float stride, float scale) {
        this.legLeftUpper.xRot = 0.18F + stride * 0.85F * scale;
        this.legRightUpper.xRot = 0.18F - stride * 0.85F * scale;
        this.legLeftLower.xRot = 0.28F + Math.max(0.0F, -stride) * 0.55F * scale;
        this.legRightLower.xRot = 0.28F + Math.max(0.0F, stride) * 0.55F * scale;
    }

    /** xRot commun, zRot gauche (le droit est l'opposé), xRot de l'avant-bras, oscillation ajoutée. */
    private void poseArms(float upperPitch, float leftRoll, float forearmPitch, float sway) {
        this.armLeftUpper.xRot = upperPitch + sway;
        this.armRightUpper.xRot = upperPitch - sway;
        this.armLeftUpper.zRot = leftRoll;
        this.armRightUpper.zRot = -leftRoll;
        this.armLeftLower.xRot = forearmPitch;
        this.armRightLower.xRot = forearmPitch;
    }

    private void writhe(float age, float speed, float amount) {
        for (int i = 0; i < this.tendrils.length; i++) {
            float phase = i * 0.65F;
            this.tendrils[i].xRot += Mth.sin(age * speed + phase) * amount;
            this.tendrils[i].zRot += Mth.cos(age * speed * 0.8F + phase) * amount * 0.7F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay, float red, float green, float blue, float alpha) {
        this.setGlowVisible(false);
        try {
            this.pivot.render(pose, buffer, light, overlay, red, green, blue, alpha);
        } finally {
            this.setGlowVisible(true);
        }
    }

    public void renderEyes(PoseStack pose, VertexConsumer buffer, int light, int overlay, float red, float green, float blue, float alpha) {
        this.renderGlow(pose, buffer, light, overlay, red, green, blue, alpha, this.eyes);
    }

    private void renderGlow(PoseStack pose, VertexConsumer buffer, int light, int overlay, float red, float green, float blue, float alpha, GlowPart[] parts) {
        for (GlowPart glow : parts) {
            pose.pushPose();
            for (ModelPart ancestor : glow.ancestors) {
                ancestor.translateAndRotate(pose);
            }
            glow.part.render(pose, buffer, light, overlay, red, green, blue, alpha);
            pose.popPose();
        }
    }

    private void setGlowVisible(boolean visible) {
        for (ModelPart part : this.glowParts) {
            part.visible = visible;
        }
    }

    private static GlowPart glow(ModelPart parent, String name, ModelPart[] ancestors) {
        return new GlowPart(parent.getChild(name), ancestors);
    }

    private record GlowPart(ModelPart part, ModelPart[] ancestors) {
    }
}

package com.niferx.canopystalker.registry;

import com.niferx.canopystalker.CanopyStalkerMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CanopyStalkerMod.MOD_ID);

    public static final RegistryObject<Item> CANOPY_STALKER_SPAWN_EGG = ITEMS.register("canopy_stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.CANOPY_STALKER, 0x1A2416, 0x9B2DFF, new Item.Properties()));

    private ModItems() {
    }
}

package com.niferx.canopystalker.entity.ai;

/**
 * Cycle du Caméléon de la canopée.
 *
 * <pre>
 * CAMOUFLAGE --joueur à portée, à l'ombre--> STALKING
 * STALKING --regard + ligne de vue---------> GAZE_AGGRO
 * GAZE_AGGRO --compteur atteint------------> CHARGE_ATTACK
 * GAZE_AGGRO --regard perdu, compteur à 0--> STALKING
 * CHARGE_ATTACK --cible perdue--------------> RETREAT_HIDE
 * RETREAT_HIDE --couvert atteint------------> CAMOUFLAGE
 * </pre>
 *
 * L'ordinal est synchronisé au client. Le NBT stocke le nom, pour survivre
 * à un réordonnancement futur de l'enum.
 */
public enum CanopyStalkerState {
    CAMOUFLAGE,
    STALKING,
    GAZE_AGGRO,
    CHARGE_ATTACK,
    RETREAT_HIDE;

    private static final CanopyStalkerState[] VALUES = values();

    public byte id() {
        return (byte) this.ordinal();
    }

    /** Camouflage et regard tenu : pas de cycle de marche, seulement le souffle des lianes. */
    public boolean isStill() {
        return this == CAMOUFLAGE || this == GAZE_AGGRO;
    }

    public static CanopyStalkerState byId(byte id) {
        int index = id & 255;
        if (index >= VALUES.length) {
            return CAMOUFLAGE;
        }
        return VALUES[index];
    }
}

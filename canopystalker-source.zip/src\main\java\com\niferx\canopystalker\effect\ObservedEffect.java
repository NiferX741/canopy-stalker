package com.niferx.canopystalker.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** Marque le joueur fixé. Le tremblement de caméra est côté client. */
public class ObservedEffect extends MobEffect {
    public ObservedEffect() {
        super(MobEffectCategory.HARMFUL, 0xD5E4FF);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return false;
    }
}

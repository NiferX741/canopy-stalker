package com.niferx.canopystalker.config;

import com.niferx.canopystalker.CanopyStalkerMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.config.ModConfigEvent;

/**
 * Valeurs lues par l'IA. Les champs statiques sont recopiés à chaque chargement
 * de config, donc un changement dans {@code canopystalker-common.toml} s'applique
 * sans recompiler. Vie, dégâts et vitesse sont aussi repoussés sur les entités
 * déjà spawn (voir {@code CanopyStalkerEntity}).
 */
@Mod.EventBusSubscriber(modid = CanopyStalkerMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class CanopyStalkerConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    private static final ForgeConfigSpec.DoubleValue MAX_HEALTH = BUILDER
            .comment("Points de vie au spawn, et après un rechargement de config.")
            .defineInRange("maxHealth", 32.0D, 1.0D, 1024.0D);
    private static final ForgeConfigSpec.DoubleValue ATTACK_DAMAGE = BUILDER
            .comment("Dégâts de la charge, avant l'effet de statut.")
            .defineInRange("attackDamage", 6.0D, 0.0D, 2048.0D);
    private static final ForgeConfigSpec.DoubleValue MOVEMENT_SPEED = BUILDER
            .comment("Attribut minecraft:generic.movement_speed. Les vitesses d'IA sont des multiplicateurs de cette valeur.")
            .defineInRange("movementSpeed", 0.26D, 0.01D, 2.0D);
    private static final ForgeConfigSpec.DoubleValue ARMOR = BUILDER
            .defineInRange("armor", 2.0D, 0.0D, 30.0D);
    private static final ForgeConfigSpec.DoubleValue KNOCKBACK_RESISTANCE = BUILDER
            .defineInRange("knockbackResistance", 0.35D, 0.0D, 1.0D);
    private static final ForgeConfigSpec.DoubleValue FOLLOW_RANGE = BUILDER
            .comment("Attribut vanilla. L'IA utilise noticeRange et loseTargetRange, pas cet attribut.")
            .defineInRange("followRange", 40.0D, 1.0D, 128.0D);

    private static final ForgeConfigSpec.DoubleValue NOTICE_RANGE = BUILDER
            .comment("Distance à laquelle un stalker camouflé commence à observer un joueur.")
            .defineInRange("noticeRange", 32.0D, 4.0D, 128.0D);
    private static final ForgeConfigSpec.DoubleValue LOSE_TARGET_RANGE = BUILDER
            .comment("Au-delà, la cible est abandonnée et le stalker se replie.")
            .defineInRange("loseTargetRange", 48.0D, 4.0D, 160.0D);
    private static final ForgeConfigSpec.DoubleValue PREFERRED_STALK_DISTANCE = BUILDER
            .comment("S'il est plus loin que ça, il se rapproche de perchoir en perchoir, sans foncer sur le joueur.")
            .defineInRange("preferredStalkDistance", 18.0D, 4.0D, 64.0D);
    private static final ForgeConfigSpec.DoubleValue GAZE_RANGE = BUILDER
            .defineInRange("gazeRange", 36.0D, 2.0D, 96.0D);
    private static final ForgeConfigSpec.DoubleValue GAZE_BOX_INFLATE = BUILDER
            .comment("Marge ajoutée à la hitbox pour le test de visée. Plus haut = regard plus facile à déclencher.")
            .defineInRange("gazeBoxInflate", 0.25D, 0.0D, 2.0D);
    private static final ForgeConfigSpec.IntValue GAZE_TICKS_REQUIRED = BUILDER
            .comment("Ticks de regard continu avant la charge. 20 ticks = 1 seconde. 70 ticks = 3,5 secondes.")
            .defineInRange("gazeTicksRequired", 70, 1, 20 * 60);
    private static final ForgeConfigSpec.IntValue GAZE_DECAY_PER_TICK = BUILDER
            .comment("Ticks retirés à chaque tick où le joueur ne regarde plus. Une grande valeur réinitialise le compteur presque d'un coup.")
            .defineInRange("gazeDecayPerTick", 2, 1, 100);
    private static final ForgeConfigSpec.IntValue EYE_GLINT_INTERVAL = BUILDER
            .defineInRange("eyeGlintInterval", 6, 1, 40);

    private static final ForgeConfigSpec.IntValue CHARGE_MAX_TICKS = BUILDER
            .defineInRange("chargeMaxTicks", 50, 10, 20 * 30);
    private static final ForgeConfigSpec.DoubleValue CHARGE_SPEED = BUILDER
            .comment("Multiplicateur de movementSpeed pendant la charge.")
            .defineInRange("chargeSpeed", 1.5D, 0.2D, 4.0D);
    private static final ForgeConfigSpec.DoubleValue STALK_SPEED = BUILDER
            .defineInRange("stalkSpeed", 0.7D, 0.05D, 2.0D);
    private static final ForgeConfigSpec.DoubleValue RETREAT_SPEED = BUILDER
            .defineInRange("retreatSpeed", 1.15D, 0.1D, 3.0D);
    private static final ForgeConfigSpec.IntValue RETREAT_MAX_TICKS = BUILDER
            .defineInRange("retreatMaxTicks", 160, 20, 20 * 60);
    private static final ForgeConfigSpec.IntValue IMPACT_PAUSE_TICKS = BUILDER
            .comment("Immobilité après un coup au but, avant le repli.")
            .defineInRange("impactPauseTicks", 8, 0, 40);
    private static final ForgeConfigSpec.IntValue PERCH_RADIUS = BUILDER
            .defineInRange("perchRadius", 14, 4, 32);
    private static final ForgeConfigSpec.DoubleValue ATTACK_REACH_BONUS = BUILDER
            .comment("Ajouté au carré de la portée de mêlée vanilla, pour les bras longs.")
            .defineInRange("attackReachBonus", 1.75D, 0.0D, 16.0D);

    private static final ForgeConfigSpec.ConfigValue<String> ATTACK_EFFECT = BUILDER
            .comment("Effet appliqué en plus des dégâts. Exemples : minecraft:poison, minecraft:slowness.")
            .define("attackEffect", "minecraft:poison", CanopyStalkerConfig::validEffectId);
    private static final ForgeConfigSpec.IntValue EFFECT_DURATION = BUILDER
            .defineInRange("attackEffectDuration", 100, 1, 20 * 120);
    private static final ForgeConfigSpec.IntValue EFFECT_AMPLIFIER = BUILDER
            .comment("0 = niveau I.")
            .defineInRange("attackEffectAmplifier", 0, 0, 5);

    private static final ForgeConfigSpec.BooleanValue AVOID_DAYLIGHT = BUILDER
            .comment("En plein soleil, le stalker interrompt l'observation et retourne sous le couvert. La charge déjà lancée va au bout.")
            .define("avoidDaylight", true);
    private static final ForgeConfigSpec.BooleanValue REQUIRE_NIGHT_TO_SPAWN = BUILDER
            .comment("Si vrai, le spawn naturel exige la nuit en plus de l'obscurité et d'un feuillage au-dessus.")
            .define("requireNightToSpawn", false);

    public static final ForgeConfigSpec SPEC = BUILDER.build();

    public static double maxHealth = 32.0D;
    public static double attackDamage = 6.0D;
    public static double movementSpeed = 0.26D;
    public static double armor = 2.0D;
    public static double knockbackResistance = 0.35D;
    public static double followRange = 40.0D;
    public static double noticeRange = 32.0D;
    public static double loseTargetRange = 48.0D;
    public static double preferredStalkDistance = 18.0D;
    public static double gazeRange = 36.0D;
    public static double gazeBoxInflate = 0.25D;
    public static int gazeTicksRequired = 70;
    public static int gazeDecayPerTick = 2;
    public static int eyeGlintInterval = 6;
    public static int chargeMaxTicks = 50;
    public static double chargeSpeed = 1.5D;
    public static double stalkSpeed = 0.7D;
    public static double retreatSpeed = 1.15D;
    public static int retreatMaxTicks = 160;
    public static int impactPauseTicks = 8;
    public static int perchRadius = 14;
    public static double attackReachBonus = 1.75D;
    public static String attackEffect = "minecraft:poison";
    public static int effectDuration = 100;
    public static int effectAmplifier = 0;
    public static boolean avoidDaylight = true;
    public static boolean requireNightToSpawn = false;

    private CanopyStalkerConfig() {
    }

    private static boolean validEffectId(Object value) {
        if (!(value instanceof String raw)) {
            return false;
        }
        return ResourceLocation.tryParse(raw) != null;
    }

    @SubscribeEvent
    static void onLoad(ModConfigEvent event) {
        if (event.getConfig().getSpec() != SPEC) {
            return;
        }
        maxHealth = MAX_HEALTH.get();
        attackDamage = ATTACK_DAMAGE.get();
        movementSpeed = MOVEMENT_SPEED.get();
        armor = ARMOR.get();
        knockbackResistance = KNOCKBACK_RESISTANCE.get();
        followRange = FOLLOW_RANGE.get();
        noticeRange = NOTICE_RANGE.get();
        loseTargetRange = LOSE_TARGET_RANGE.get();
        preferredStalkDistance = PREFERRED_STALK_DISTANCE.get();
        gazeRange = GAZE_RANGE.get();
        gazeBoxInflate = GAZE_BOX_INFLATE.get();
        gazeTicksRequired = GAZE_TICKS_REQUIRED.get();
        gazeDecayPerTick = GAZE_DECAY_PER_TICK.get();
        eyeGlintInterval = EYE_GLINT_INTERVAL.get();
        chargeMaxTicks = CHARGE_MAX_TICKS.get();
        chargeSpeed = CHARGE_SPEED.get();
        stalkSpeed = STALK_SPEED.get();
        retreatSpeed = RETREAT_SPEED.get();
        retreatMaxTicks = RETREAT_MAX_TICKS.get();
        impactPauseTicks = IMPACT_PAUSE_TICKS.get();
        perchRadius = PERCH_RADIUS.get();
        attackReachBonus = ATTACK_REACH_BONUS.get();
        attackEffect = ATTACK_EFFECT.get();
        effectDuration = EFFECT_DURATION.get();
        effectAmplifier = EFFECT_AMPLIFIER.get();
        avoidDaylight = AVOID_DAYLIGHT.get();
        requireNightToSpawn = REQUIRE_NIGHT_TO_SPAWN.get();
    }
}
